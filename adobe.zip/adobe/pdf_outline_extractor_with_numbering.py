import fitz  # PyMuPDF
import json
import sys
import os
import re
import io
import numpy as np
from sklearn.cluster import KMeans
import spacy
import pytesseract
from PIL import Image
import glob

# Load spaCy model once globally
nlp = spacy.load("en_core_web_sm")

# Regex to recognize typical headings
heading_pattern = re.compile(r'^(\d+(\.\d+)*)?\.?\s?[A-Z][a-zA-Z0-9\s\-\,]{1,100}$')

# Blacklist regex patterns to reject false headings
FALSE_HEADING_PATTERNS = [
    r"^Page \d+",
    r"^Figure \d+",
    r"^Table of Contents",
    r"^Copyright",
    r"^All rights reserved",
    r"^Confidential",
    r"^Appendix",
    r"^\s*$"
]

def is_likely_heading(text):
    words = text.split()
    if len(words) == 0 or len(words) > 8:
        return False
    cap_words = sum(1 for w in words if w and w[0].isupper())
    if cap_words < 0.7 * len(words):
        return False
    for pattern in FALSE_HEADING_PATTERNS:
        if re.match(pattern, text, re.IGNORECASE):
            return False
    if heading_pattern.match(text):
        return True
    return False

def nlp_heading_filter(text):
    doc = nlp(text)
    num_title = sum(1 for token in doc if token.text.istitle() and not token.is_stop)
    if num_title >= len(doc) / 2 and len(doc) < 12:
        return True
    roots = [token for token in doc if token.head == token]
    if roots and roots[0].pos_ in ("NOUN", "PROPN") and len(doc) < 12:
        return True
    return False

def cluster_font_sizes(font_sizes_dict):
    font_sizes_list = []
    for size, freq in font_sizes_dict.items():
        font_sizes_list.extend([size] * freq)
    if not font_sizes_list:
        return {}
    font_sizes_arr = np.array(font_sizes_list).reshape(-1, 1)
    n_clusters = min(3, len(set(font_sizes_list)))
    if n_clusters == 0:
        return {}
    kmeans = KMeans(n_clusters=n_clusters, random_state=42).fit(font_sizes_arr)
    centers = sorted(kmeans.cluster_centers_.flatten(), reverse=True)
    levels = {}
    assigned_sizes = set()
    for idx, center in enumerate(centers):
        level = ['H1', 'H2', 'H3'][idx]
        for size in font_sizes_dict.keys():
            if size in assigned_sizes:
                continue
            if abs(size - center) < 1.0:  # 1pt tolerance
                levels[size] = level
                assigned_sizes.add(size)
    return levels

def extract_numeric_prefix(text):
    """Extract numbering prefix (e.g. '1', '1.1', '2.3.1')."""
    match = re.match(r'^(\d+(\.\d+){0,2})\.?\s', text)
    return match.group(1) if match else None

def numbering_based_level(text):
    """
    Assign heading level based on numeric prefix depth.
    '1' -> H1, '1.1' -> H2, '1.1.1' -> H3.
    """
    prefix = extract_numeric_prefix(text)
    if not prefix:
        return None
    parts = prefix.split('.')
    if len(parts) == 1:
        return 'H1'
    elif len(parts) == 2:
        return 'H2'
    elif len(parts) >= 3:
        return 'H3'
    return None

def check_heading_sequence(headings, autofill=False):
    last_num_parts = None
    filled_headings = []
    warnings = []
    for h in headings:
        prefix = extract_numeric_prefix(h['text'])
        if not prefix:
            filled_headings.append(h)
            continue
        parts = list(map(int, prefix.split('.')))
        if last_num_parts:
            for idx in range(min(len(parts), len(last_num_parts))):
                if parts[idx] > last_num_parts[idx] + 1:
                    warning = f"[Warning] Possible missing heading(s) between {'.'.join(map(str, last_num_parts))} and {prefix}"
                    print(warning)
                    warnings.append(warning)
                    if autofill:
                        missing_level = h['level']
                        missing_text = f"Missing Section {last_num_parts[idx] + 1}"
                        missing_heading = {
                            "level": missing_level,
                            "text": missing_text,
                            "page": h['page']
                        }
                        filled_headings.append(missing_heading)
        filled_headings.append(h)
        last_num_parts = parts
    return filled_headings, warnings

def ocr_page(page, zoom=2):
    mat = fitz.Matrix(zoom, zoom)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    img = Image.open(io.BytesIO(pix.tobytes()))
    text = pytesseract.image_to_string(img)
    lines = text.splitlines()
    return [line.strip() for line in lines if line.strip()]

def extract_title(doc, first_page_ocr_lines=None):
    title = doc.metadata.get("title")
    if title and title.strip():
        return title.strip()
    page = doc[0]
    blocks = page.get_text("dict")["blocks"]
    max_size = 0
    title_text = ""
    for b in blocks:
        for l in b.get("lines", []):
            for s in l.get("spans", []):
                if s["size"] > max_size and s["text"].strip():
                    max_size = s["size"]
                    title_text = s["text"]
    if title_text.strip():
        return title_text.strip()
    # Fallback with OCR first lines
    if first_page_ocr_lines:
        for line in first_page_ocr_lines:
            if len(line) > 3:
                return line
    return "Untitled Document"

def filter_headings(headings):
    blacklist_phrases = [
        "page", "figure", "copyright", "all rights reserved", "confidential", "appendix"
    ]
    filtered = []
    for h in headings:
        text_lower = h["text"].lower()
        if any(phrase in text_lower for phrase in blacklist_phrases):
            continue
        filtered.append(h)
    return filtered

def extract_headings(doc, max_pages=50, autofill_missing=True):
    headings = []
    font_sizes = {}
    num_pages = min(len(doc), max_pages)
    ocr_pages_texts = {}

    # Step 1: Collect font sizes from text pages or mark pages with no text for OCR
    for i in range(num_pages):
        page = doc[i]
        blocks = page.get_text("dict")["blocks"]
        total_text = page.get_text().strip()
        if not total_text:
            ocr_lines = ocr_page(page)
            ocr_pages_texts[i] = ocr_lines
        else:
            for b in blocks:
                for l in b.get("lines", []):
                    for s in l.get("spans", []):
                        fs = s["size"]
                        font_sizes[fs] = font_sizes.get(fs, 0) + 1

    size_to_level = cluster_font_sizes(font_sizes)

    # Step 2: Extract headings from pages
    for i in range(num_pages):
        page = doc[i]
        if i in ocr_pages_texts:
            # OCR pages - no font information
            ocr_lines = ocr_pages_texts[i]
            for line in ocr_lines:
                if len(line) > 3 and is_likely_heading(line) and nlp_heading_filter(line):
                    # Use numbering heuristic if present or default H2 for OCR lines
                    level = numbering_based_level(line) or "H2"
                    headings.append({
                        "level": level,
                        "text": line,
                        "page": i + 1
                    })
        else:
            # Text pages
            blocks = page.get_text("dict")["blocks"]
            for b in blocks:
                for l in b.get("lines", []):
                    for s in l.get("spans", []):
                        fs = s["size"]
                        text = s["text"].strip()
                        if not text or len(text) > 120:
                            continue
                        level_font = size_to_level.get(fs)
                        level_num = numbering_based_level(text)
                        # Prioritize numbering-based level if exists
                        level = level_num or level_font
                        if level and is_likely_heading(text) and nlp_heading_filter(text):
                            headings.append({
                                "level": level,
                                "text": text,
                                "page": i + 1
                            })

    # Step 3: Sort and check sequence
    headings.sort(key=lambda x: (x['page'], x['level'], x['text']))
    headings, _ = check_heading_sequence(headings, autofill=autofill_missing)

    # Step 4: Filter false positives
    headings = filter_headings(headings)
    return headings

def pdf_to_outline_json(pdf_path, output_json_path=None, autofill_missing=True):
    doc = fitz.open(pdf_path)
    first_page_text = doc[0].get_text().strip()
    first_page_ocr_lines = None
    if not first_page_text:
        first_page_ocr_lines = ocr_page(doc[0])
    title = extract_title(doc, first_page_ocr_lines=first_page_ocr_lines)
    outline = extract_headings(doc, autofill_missing=autofill_missing)
    result = {
        "title": title,
        "outline": outline
    }
    if output_json_path:
        with open(output_json_path, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        print(f"JSON saved to {output_json_path}")
    else:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    return result

def batch_outline(input_folder, output_folder, autofill_missing=True):
    os.makedirs(output_folder, exist_ok=True)
    for pdf_path in glob.glob(os.path.join(input_folder, "*.pdf")):
        basename = os.path.splitext(os.path.basename(pdf_path))[0]
        output_path = os.path.join(output_folder, f"{basename}.json")
        print(f"Processing {pdf_path}...")
        pdf_to_outline_json(pdf_path, output_path, autofill_missing=autofill_missing)

def print_usage():
    print("Usage:")
    print("  python pdf_outline_extractor_with_numbering.py input.pdf output.json")
    print("  python pdf_outline_extractor_with_numbering.py --batch input_folder output_folder")

if _name_ == "__main__":
    if len(sys.argv) < 2:
        print_usage()
        sys.exit(1)

    if sys.argv[1] == "--batch":
        if len(sys.argv) != 4:
            print("Batch mode requires: input_folder output_folder")
            sys.exit(1)
        input_folder = sys.argv[2]
        output_folder = sys.argv[3]
        batch_outline(input_folder, output_folder)
    else:
        if len(sys.argv) != 3:
            print_usage()
            sys.exit(1)
        pdf_file = sys.argv[1]
        output_json = sys.argv[2]
        if not os.path.isfile(pdf_file):
            print(f"File not found: {pdf_file}")
            sys.exit(2)
        pdf_to_outline_json(pdf_file, output_json)
